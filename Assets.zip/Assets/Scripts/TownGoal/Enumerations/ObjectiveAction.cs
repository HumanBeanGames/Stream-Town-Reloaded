namespace TownGoal.Enumerations 
{
    public enum ObjectiveType 
	{
       Build,
	   BuildAny,
	   Collect,
	   Kill,
	   KillAny,
	   EarnPerHour,
	   Sell,
	   SellAny,
	   Buy,
	   BuyAny
    }
}