namespace Requirements 
{
    public enum RequirementType
	{
		Technology,
		RoleLevel,
		Role,
		Building,
		Resource

	}
}