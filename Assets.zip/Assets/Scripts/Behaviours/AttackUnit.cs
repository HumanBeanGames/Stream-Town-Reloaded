using UnityEngine;

namespace Behaviours
{
	public class AttackUnit : HealthModifier
	{

	}
}