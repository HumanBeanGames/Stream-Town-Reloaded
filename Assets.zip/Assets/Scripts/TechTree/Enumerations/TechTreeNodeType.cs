namespace TechTree.Enumerations 
{
    public enum TechTreeNodeType 
	{
        SingleChoice,
		MultipleChoice
    }
}