namespace Character.Enumerations 
{
    public enum ActivityStatus 
	{
        Active= 0,
		LastTenMinutes = 1,
		LastHour = 2,
		Inactive = 3
	}
}