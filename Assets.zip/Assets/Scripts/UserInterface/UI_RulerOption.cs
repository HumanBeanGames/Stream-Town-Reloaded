using TMPro;
using UnityEngine;

namespace UserInterface
{
	public class UI_RulerOption : MonoBehaviour
	{
		public TextMeshProUGUI TextTMP;
	}
}