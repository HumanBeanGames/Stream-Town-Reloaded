using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace UserInterface 
{
    public class UI_Objective : MonoBehaviour 
	{
        public TextMeshProUGUI ObjectiveText;
        public Slider ObjectiveSlider;
        public TextMeshProUGUI AmountTMP;
    }
}