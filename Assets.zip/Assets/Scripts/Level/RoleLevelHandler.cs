namespace Level
{
	public class RoleLevelHandler : LevelHandler
	{

	}
}
