namespace Buildings
{
	public class BuildCostModifier
	{
		public int Modifier { get; set; } = 0;
	}
}