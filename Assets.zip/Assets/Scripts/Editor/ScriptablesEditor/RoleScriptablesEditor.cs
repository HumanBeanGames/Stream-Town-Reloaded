namespace ScriptablesEditor 
{
    public static class RoleScriptablesEditor 
	{
        
    }
}