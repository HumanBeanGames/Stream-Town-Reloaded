namespace Pets.Enumerations 
{
    public enum PetType 
	{
        None,
        RedPanda,
        FishGod,
        Giraffe,
		Duck,
		Butterfly,
		Count
    }
}