using System.Collections.Generic;

namespace Managers
{
	public static class UpdateManager
	{
		//public static List<IUpdater> _objects = new List<IUpdater>();

		//public static void AddObject(IUpdater obj)
		//{
		//	if (_objects.Contains(obj))
		//		return;

		//	_objects.Add(obj);
		//}

		//public static void RemoveObject(IUpdater obj)
		//{
		//	if (_objects.Contains(obj))
		//		_objects.Remove(obj);
		//}

		//public static void Update()
		//{
		//	for (int i = 0; i < _objects.Count; i++)
		//	{
		//		_objects[i].OnUpdate();
		//	}
		//}
	}
}