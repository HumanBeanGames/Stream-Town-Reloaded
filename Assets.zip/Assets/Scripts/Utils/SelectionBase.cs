using UnityEngine;

namespace Utils
{
	[SelectionBase]
	public class SelectionBase : MonoBehaviour
	{

	}
}