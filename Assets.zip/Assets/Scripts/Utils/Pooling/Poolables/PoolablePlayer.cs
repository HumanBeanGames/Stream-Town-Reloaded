namespace Utils.Pooling.Poolables 
{
    public class PoolablePlayer 
	{
        
    }
}